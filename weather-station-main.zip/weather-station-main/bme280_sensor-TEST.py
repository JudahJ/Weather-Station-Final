import bme280
import smbus2
from time import sleep

port = 1
address = 0x77 # Adafruit BME280 address. Other BME280s may be different
bus = smbus2.SMBus(port)

bme280.load_calibration_params(bus,address)

def read_all(): 
    bme280_data = bme280.sample(bus,address)
    humidity  = bme280_data.humidity
    pressure  = bme280_data.pressure
    ambient_temperature = bme280_data.temperature
    #print(humidity, pressure, ambient_temperature)
    return humidity, pressure, ambient_temperature

#ask how readings to take 
numReadings = int(input("How many readings do you want (1/sec)?"))

for x in range(numReadings):
     hum, pres, temp = read_all()

     #print ("after function return")
     print ("humidity: ", hum, ", pressure: ", pres, ", temp (C): ", temp)
     sleep(1)


